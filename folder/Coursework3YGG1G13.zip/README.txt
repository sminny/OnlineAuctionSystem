The following Online Auction System is from the following

After compilation:
Client side application - ClientMain.java
Server side application - ServerMain.java

There is a JPG picture,inside the zip, which is relevent to the
compilation of the programme -"happinness.jpg", which is used
as a deafault picture for the pictures in both applications.

Extentions:
-Sockets
-Images
-Security(hashing)
-Search engine
-Cancelling and penalizing users for breaking regulations

In order to run the application, the following need to be
executed
(all files in same directory)
javac *.java --> java ServerMain

seperate terminal java ClientMain
